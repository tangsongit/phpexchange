#!/bin/sh
###
 # @Descripttion: 
 # @version: 
 # @Author: GuaPi
 # @Date: 2021-10-17 17:00:24
 # @LastEditors: GuaPi
 # @LastEditTime: 2021-10-19 19:50:18
### 
php depth.php stop & php trade.php stop & php market.php stop & php kline_1min.php stop & php kline_5min.php stop & php kline_15min.php stop & php kline_30min.php stop & php kline_60min.php stop & php kline_1day.php stop & php kline_1week.php stop & php kline_1mon.php stop & php kline_4hour.php stop
