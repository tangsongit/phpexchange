#!/bin/sh
###
 # @Descripttion: 
 # @version: 
 # @Author: GuaPi
 # @Date: 2021-10-17 17:00:24
 # @LastEditors: GuaPi
 # @LastEditTime: 2021-10-28 23:56:24
### 
php swap_depth.php start & php swap_trade.php start & php swap_market.php start & php swap_kline_1min.php start & php swap_kline_5min.php start & php swap_kline_15min.php start & php swap_kline_30min.php start & php swap_kline_60min.php start & php swap_kline_4hour.php start & php swap_kline_1day.php start & php swap_kline_1week.php start & php swap_kline_1mon.php start 
