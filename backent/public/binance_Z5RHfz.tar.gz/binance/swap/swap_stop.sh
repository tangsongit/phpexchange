#!/bin/sh
###
 # @Descripttion: 
 # @version: 
 # @Author: GuaPi
 # @Date: 2021-10-17 17:00:24
 # @LastEditors: GuaPi
 # @LastEditTime: 2021-10-19 19:50:42
### 
php swap_depth.php stop & php swap_trade.php stop & php swap_market.php stop & php swap_kline_1min.php stop & php swap_kline_5min.php stop & php swap_kline_15min.php stop & php swap_kline_30min.php stop & php swap_kline_60min.php stop & php swap_kline_4hour.php stop & php swap_kline_1day.php stop & php swap_kline_1week.php stop & php swap_kline_1mon.php stop & php swap_kline_4hour.php stop
